import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import os

# Load the dataset (place spotify_top50.csv in the same directory as this script)
df = pd.read_csv('spotify_top50.csv')

# 1. Basic information
print("Data Info:")
print(df.info())
print("\nHead of Data:")
print(df.head())
print("\nDescriptive Statistics:")
print(df.describe())

# Create plots directory
os.makedirs('plots', exist_ok=True)

# 2. Category Distributions
plt.figure(figsize=(6,4))
sns.countplot(x='key', data=df)
plt.title('Distribution of Key')
plt.savefig('plots/key_countplot.png')
plt.clf()

plt.figure(figsize=(6,4))
sns.countplot(x='time_signature', data=df)
plt.title('Distribution of Time Signature')
plt.savefig('plots/time_signature_countplot.png')
plt.clf()

# 3. Continuous Variables Histograms
numeric_cols = ['danceability','energy','loudness','speechiness',
                'acousticness','instrumentalness','liveness','valence','tempo']
df[numeric_cols].hist(bins=15, figsize=(12,10))
plt.tight_layout()
plt.savefig('plots/numeric_histograms.png')
plt.clf()

# 4. Correlation Heatmap
corr = df[numeric_cols + ['position']].corr()
plt.figure(figsize=(10,8))
sns.heatmap(corr, annot=True, fmt=".2f", cmap='coolwarm')
plt.title('Correlation Matrix')
plt.savefig('plots/correlation_heatmap.png')
plt.clf()

# 5. Scatter Plots vs. Position
for col in ['energy', 'danceability', 'valence', 'loudness']:
    plt.figure(figsize=(6,4))
    sns.scatterplot(x=col, y='position', data=df)
    plt.gca().invert_yaxis()
    plt.title(f'{col.capitalize()} vs. Position')
    plt.savefig(f'plots/{col}_vs_position.png')
    plt.clf()

# 6. Random Forest Feature Importances
X = df[numeric_cols]
y = df['position']
X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=42)
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)
importances = pd.Series(model.feature_importances_, index=X.columns).sort_values(ascending=False)

plt.figure(figsize=(8,4))
importances.plot(kind='bar')
plt.gca().invert_yaxis()
plt.title('Feature Importances for Position Prediction')
plt.tight_layout()
plt.savefig('plots/feature_importances.png')
plt.clf()

print("EDA complete. Plots saved in the 'plots' directory.")
