# Spotify Top 50 EDA

This project contains exploratory data analysis (EDA) for the "World's Spotify Top 50" dataset.

## Contents
- `eda.py`: Python script performing the analysis and saving plots.
- `Top-50-musicality-global.csv`: Spotify Top 50 dataset.
- `plots/`: Directory where the generated plot images are saved.
- `requirements.txt`: List of Python dependencies.

## Setup
1. Ensure `Top-50-musicality-global.csv` is present in the project directory.
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Run the analysis:
   ```
   python eda.py
   ```

## Outputs
- Basic data info printed to console.
- Visualizations saved as PNGs in the `plots/` folder.
